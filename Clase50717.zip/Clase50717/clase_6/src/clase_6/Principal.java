/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clase_6;

/**
 *
 * @author Dell
 */
public class Principal {
    public static void main(String[] args){
       Estudiante e1=new Estudiante ();
       Estudiante e2 = new Estudiante ();
       int suma_edades=0;
       double promedio=0;
       String valor_nombre = "Luis";
       e1.agregar_nombre(valor_nombre);
       e1.agregar_nombre("Maria");
       
       e1.agregar_edad(18);
       e2.agregar_edad(17);
       suma_edades= e1.obtener_edad()+e2.obtener_edad();
       promedio=(double)suma_edades/2;
       System.out.println(promedio);
    }
}
