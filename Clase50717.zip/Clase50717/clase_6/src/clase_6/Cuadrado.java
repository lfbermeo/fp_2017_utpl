
package clase_6;


public class Cuadrado {
    private int lado; 
    public void generar_reporte (int l){
        lado = l;
    }
    public int obtener_lado(){
     return lado;   
    } 
    public int calcular_area(){
     //int area = lado*lado;
     int area = obtener_lado()*obtener_lado();
     return area;
     }
    public int calcular_perimetro(){
     int perimetro = obtener_lado()+obtener_lado()+obtener_lado()+ obtener_lado();
     return perimetro;
        
    }
}

