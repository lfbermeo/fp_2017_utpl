package clase_6;

import java.util.Scanner;

public class Principal_cuadrado {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        for (int i = 1; i <= 5; i++) {

            System.out.println("Ingrese el valor del lado");
            int lado = entrada.nextInt();
            Cuadrado c = new Cuadrado();
            c.agregar_lado(lado);
            System.out.printf("Cuadrado con lado %d\n\tÁrea=%d\n\t Perimetro=%d\n\t", c.obtener_lado(), c.calcular_area(), c.calcular_perimetro());

        }
    }
}
